import os
from PIL import Image, ImageOps, ImageFilter

filename = "img/clungup.jpg"

im = Image.open(filename)

# Filter
#out = im.filter(ImageFilter.BLUR)
out = im.filter(ImageFilter.FIND_EDGES)
#out = im.filter(ImageFilter.CONTOUR)

# ImageOps
#out = ImageOps.grayscale(im)
#out = ImageOps.solarize(im)

#im.show()
out.show()

